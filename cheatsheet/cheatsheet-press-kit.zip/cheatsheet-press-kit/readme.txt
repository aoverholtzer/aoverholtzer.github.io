Cheatsheet
Version 1.0 for iOS 8

App Store: http://itunes.apple.com/app/id914665829
Website: http://overdesigned.net/cheatsheet
Contact: cheatsheet@overdesigned.net

Cheatsheet is for the little things you never remember: hotel rooms, license plates, luggage combination, employee ID number. Write things down in Cheatsheet and then refer to them anytime in the Cheatsheet Today Widget. No more fumbling to unlock your phone and find your notes app; Cheatsheet is as easy as pulling down Notification Center.

App Features:
- Simple UI for adding and managing your cheats.
- 18 hint icons to help you recognize what you’re looking for.
- Quickly copy a cheat by tapping-and-holding on a row.
- Includes easy, 3-step instructions for adding the Today Widget to your Notification Center.
- No security. Please don’t use Cheatsheet for important passwords or personal information.

Today Widget Features:
- Shows up to 10 of your cheats.
- Tap the widget to open Cheatsheet.
- Tap the “+” button to jump to the Add Cheat screen.

Cheatsheet was made by Adam Overholtzer, a UX designer and iOS developer living in California. He never remembers his employee ID number.