# Time’s Up! Press Kit

### TL;DR

Time’s Up! is a fun, visual timer that people will actually want to use. Whether it’s for adults or kids, Time’s Up! will make counting down more engaging.

There are all kinds of reasons for people to need a timer — whether it’s to bring an end to a fun activity, curb a long-running meeting, or even count down to something exciting. But one thing is constant: timers are boring. Time’s Up! fixes that with colorful artwork, photos, animation, and sound, plus integration with iOS features including AirPlay, Guided Access, Shortcuts, and Accessibility. By bringing all of this together into one, easy-to-use app, Time’s Up! makes timers fun and engaging for everyone.

No more watching boring white numbers on a black background counting down!

Time’s Up! is available for iPhone, iPad, Mac, and Apple TV, and supports iCloud syncing across all devices.

### Time’s Up! — Why did I build it?

I built Time’s Up! for a specific audience: my toddler. Timers are a great way to explain that it’s almost time to stop doing something fun without becoming the “bad guy” — my kid definitely has more respect for what my phone says than what I say. The iPhone’s timer app is very basic, so I decided to make it more fun and full-featured. That’s the thinking behind Time’s Up! — I wanted a way to show my toddler that it’s time to leave but in a way that engages instead of frustrating them.

Time’s Up! brings three key features to the timer app:

1.  Visually interesting timers, using color, animation, and photos. My kid sometimes sits and watches the timer count down because they’re so interested to see what photo will be revealed.

2.  Support for Guided Access so I can hand my phone to my kid without worrying that they’ll switch apps or change the timer.

3.  Support for TV screens via AirPlay and a tvOS app. This feature has proven surprisingly valuable to me as a parent, but could also be useful for people in offices or other group environments.

What originally started as my pandemic project has turned into an app that I think can be really useful to parents around the world. But it can be used by anyone, from adults who need to be reminded to take a break, to teenagers who need help staying focused on their homework, to gym-goers who want to know when it’s time to switch activity.

### Features

Time’s Up! includes a number of features that are designed to make managing time easier and more engaging than ever before. Time’s Up! has 5 styles to choose from, including: 

- “Reveal” a photo from your Photo Library as the seconds tick down. 

- “Pixelate” makes a photo more clear as a timer gets closer to completion.

- “Puzzle” breaks a photo into jigsaw puzzle pieces and then puts the pieces into their places as time progresses.

Alternatively, there are more traditional clock faces if people just want a simple timer. Timers can be customized with their own alert sound and color, too.

Other key features include:

- Sync timers between iPhone, iPad, Mac, and Apple TV using iCloud.

- Guided Access to prevent kids from switching apps and changing timers, making sure only you have the power to control time.

- Airplay and tvOS support so you can put a timer up on a TV screen.

### Who is Time’s Up! for?

Time’s Up! is great for:

- Adults who need to set timers to stop them from working for too long without a break.

- Kids who don’t want to do their homework but can be convinced to work in smaller chunks.

- Setting reading or other activity timers before bed time.

- Helping bigger kids with ADHD and similar conditions focus on an activity for a set amount of time.

- Setting timers for exercises and other activities.

- Anything that’s based on a specific amount of time!

### Pricing

Time’s Up! is a free download with a single one-time purchase that unlocks the ability to run an unlimited number of timers.

### A note on privacy

I believe that data belongs to users and users alone. To that end, Time’s Up! does not collect any data and there are no ads or invasive trackers in the app whatsoever. Time’s Up! is a free download, with an optional one-time in-app purchase unlocking additional features. Time’s Up! is a good App Store citizen and I feel very strongly about that.

### Links and contacts

**App Store:** https://itunes.apple.com/app/id1550456653

**Website:** https://overdesigned.net/timesup/

**Privacy Policy:** https://overdesigned.net/timesup/privacy.html

**Press Kit:** https://overdesigned.net/timesup/press-kit.zip

**Email:** adam@overdesigned.net

**Twitter:** @TimesUpApp